document.writeln("HEllo World");
document.writeln("<h1>HEllo World from JavaScript");
/* Java Script Code To add 2 number*/
var a,b,sum;

 var name=prompt("Enter your Name :");
a=parseInt(prompt("Enter first Number:", "Enter a Nuber"));
b=parseInt(prompt("Enter second number:", "Enter a number"));

sum=a+b;
document.write("hello" +name+"<br>");
document.writeln("The Addition of 2 nos is :" +sum);

alert("Thankyou "+name);